"""Core input-output calculations.

Conventions
-----------
Z[i, j]  intermediate sales from node i to node j (a node is a state x sector pair).
x[j]     total output of node j.
f[i]     final demand for node i's output.
A[i, j]  = Z[i, j] / x[j]  (inputs from i needed per unit of output of j).
L        = (I - A)^-1      (Leontief inverse).
"""
from __future__ import annotations

import numpy as np


def technical_coefficients(Z: np.ndarray, x: np.ndarray) -> np.ndarray:
    """A = Z diag(x)^-1. Columns of nodes with zero output become zero."""
    Z = np.asarray(Z, dtype=float)
    x = np.asarray(x, dtype=float)
    if Z.ndim != 2 or Z.shape[0] != Z.shape[1]:
        raise ValueError("Z must be a square matrix")
    if x.shape != (Z.shape[0],):
        raise ValueError("x must have one entry per node")
    if (Z < 0).any() or (x < 0).any():
        raise ValueError("Z and x must be non-negative")
    safe_x = np.where(x > 0, x, 1.0)
    A = Z / safe_x
    A[:, x == 0] = 0.0
    return A


def leontief_inverse(A: np.ndarray) -> np.ndarray:
    """L = (I - A)^-1. Raises if the economy is not productive."""
    n = A.shape[0]
    if (A.sum(axis=0) >= 1).any():
        raise ValueError("A has a column summing to >= 1: model is not productive")
    return np.linalg.inv(np.eye(n) - A)


def demand_shock(L: np.ndarray, delta_f: np.ndarray) -> np.ndarray:
    """Output change needed across all nodes for a change in final demand.

    Demand-driven: shows how a demand change propagates to *suppliers*.
    It is not a model of supply interruptions (see hypothetical_extraction).
    """
    return L @ np.asarray(delta_f, dtype=float)


def value_added(Z: np.ndarray, x: np.ndarray) -> np.ndarray:
    """Primary inputs per node: output minus intermediate purchases (column sums of Z)."""
    return np.asarray(x, dtype=float) - np.asarray(Z, dtype=float).sum(axis=0)


def ghosh_inverse(Z: np.ndarray, x: np.ndarray) -> np.ndarray:
    """G = (I - B)^-1 with B = diag(x)^-1 Z (output coefficients, supply-driven model)."""
    Z = np.asarray(Z, dtype=float)
    x = np.asarray(x, dtype=float)
    safe_x = np.where(x > 0, x, 1.0)
    B = Z / safe_x[:, None]
    B[x == 0, :] = 0.0
    if (B.sum(axis=1) >= 1).any():
        raise ValueError("B has a row summing to >= 1: model is not productive")
    return np.linalg.inv(np.eye(Z.shape[0]) - B)


def supply_shock(G: np.ndarray, delta_v: np.ndarray) -> np.ndarray:
    """Output change caused by a change in primary inputs (supply-driven, Ghosh).

    Shows how a supply disruption propagates to *buyers* downstream. Known
    limitation: the model assumes buyers cannot substitute other suppliers, so
    results are an upper bound on short-run exposure, not a forecast.
    """
    return np.asarray(delta_v, dtype=float) @ G


def supply_extraction(Z: np.ndarray, x: np.ndarray, nodes) -> dict:
    """Output lost by the remaining nodes if `nodes` stop selling and buying intermediates.

    Hypothetical extraction in the supply-driven model: rows and columns of B for
    the extracted nodes are zeroed and primary inputs are held fixed. The loss is
    measured on nodes outside the extracted set. Conditional on the model's
    assumptions (fixed coefficients, no substitution); not a forecast.
    """
    Z = np.asarray(Z, dtype=float)
    x = np.asarray(x, dtype=float)
    nodes = np.atleast_1d(np.asarray(nodes, dtype=int))
    n = Z.shape[0]
    v = value_added(Z, x)
    x_base = v @ ghosh_inverse(Z, x)
    Z_ex = Z.copy()
    Z_ex[nodes, :] = 0.0
    Z_ex[:, nodes] = 0.0
    safe_x = np.where(x > 0, x, 1.0)
    B_ex = Z_ex / safe_x[:, None]
    x_ex = v @ np.linalg.inv(np.eye(n) - B_ex)
    others = np.ones(n, dtype=bool)
    others[nodes] = False
    loss = x_base - x_ex
    loss[~others] = 0.0
    return {
        "loss_by_node": loss,
        "total_loss": float(loss.sum()),
        "share_of_remaining_output": float(loss.sum() / x_base[others].sum()),
    }


def input_concentration(A: np.ndarray, j: int) -> dict:
    """Herfindahl index of the inputs node j buys (1/n = diversified, 1 = single supplier)."""
    col = A[:, j]
    total = col.sum()
    if total == 0:
        return {"hhi": 0.0, "top_supplier": None, "top_share": 0.0}
    shares = col / total
    top = int(np.argmax(shares))
    return {"hhi": float((shares**2).sum()), "top_supplier": top, "top_share": float(shares[top])}
