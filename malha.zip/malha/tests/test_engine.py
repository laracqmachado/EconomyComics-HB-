import numpy as np
import pytest

from malha import (
    demand_shock,
    ghosh_inverse,
    supply_extraction,
    supply_shock,
    value_added,
    input_concentration,
    leontief_inverse,
    technical_coefficients,
)

# Toy economy, 3 nodes: 0 = raw material, 1 = components, 2 = final goods.
Z = np.array([[10.0, 30.0, 0.0],
              [0.0, 10.0, 40.0],
              [0.0, 0.0, 5.0]])
f = np.array([60.0, 50.0, 95.0])
x = Z.sum(axis=1) + f  # row balance: x_i = sum_j Z_ij + f_i


def test_coefficients_columns_below_one():
    A = technical_coefficients(Z, x)
    assert (A.sum(axis=0) < 1).all()


def test_leontief_reproduces_output():
    A = technical_coefficients(Z, x)
    np.testing.assert_allclose(leontief_inverse(A) @ f, x)


def test_demand_shock_is_linear():
    L = leontief_inverse(technical_coefficients(Z, x))
    d = np.array([0.0, 0.0, 10.0])
    np.testing.assert_allclose(demand_shock(L, 2 * d), 2 * demand_shock(L, d))
    assert (demand_shock(L, d) >= 0).all()


def test_ghosh_reproduces_output():
    v = value_added(Z, x)
    np.testing.assert_allclose(v @ ghosh_inverse(Z, x), x)


def test_supply_shock_hits_downstream_buyers():
    G = ghosh_inverse(Z, x)
    dv = np.array([-9.0, 0.0, 0.0])  # raw material loses 10% of primary inputs
    dx = supply_shock(G, dv)
    assert dx[1] < 0 and dx[2] < 0


def test_extraction_of_upstream_node_hurts_downstream():
    res = supply_extraction(Z, x, [0])
    assert res["total_loss"] > 0
    assert res["loss_by_node"][0] == 0.0
    assert res["loss_by_node"][1] > 0


def test_extraction_of_final_node_costs_suppliers_nothing():
    # node 2 only sells to final demand and itself, so removing it hurts no one downstream
    res = supply_extraction(Z, x, [2])
    assert res["total_loss"] == pytest.approx(0.0)


def test_extraction_of_isolated_node_costs_nothing():
    res = supply_extraction(np.zeros((2, 2)), np.array([100.0, 100.0]), [0])
    assert res["total_loss"] == pytest.approx(0.0)


def test_concentration_bounds():
    A = technical_coefficients(Z, x)
    c = input_concentration(A, 1)
    assert 1 / A.shape[0] <= c["hhi"] <= 1.0
    assert input_concentration(A, 0)["top_supplier"] == 0


def test_rejects_unproductive_economy():
    with pytest.raises(ValueError):
        leontief_inverse(np.array([[0.6, 0.6], [0.5, 0.5]]))
