# Data

MALHA uses the interregional input-output matrix of the **Atlas Econômico** (IPEA / Receita Federal do Brasil): 27 states x 68 economic activities, base year 2018.

- Source: https://www.ipea.gov.br/atlaseconomico/
- Raw files are **not committed** (`data/raw/` is git-ignored). Download them from the source and respect its terms of use.
- The data is aggregated; it contains no personal data.
