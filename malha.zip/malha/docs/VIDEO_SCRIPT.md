# Video script (~3 min, English preferred by the jury)

Record in one take with screen capture and your face on camera (the credits form asks each member to appear).
For the **credits draft**, a video explaining the idea is enough. Re-record before 30/11 showing the working demo.

**0:00–0:20 — Who and why.** "Hi, I'm Lara. I'm building MALHA for Hack Brasil, in the Logistics & Automation track."

**0:20–0:55 — Problem.** "Supply planners see their direct suppliers. The real risk is two or three steps upstream, hidden in huge input-output tables. Public data exists (IPEA's Atlas Econômico: 27 states, 68 sectors) but it isn't built for sourcing-risk questions."

**0:55–1:40 — Solution.** Show the repo and README. "MALHA ranks who a state-sector depends on, directly and indirectly, and measures how concentrated those inputs are."

**1:40–2:25 — Scenario.** Show the tests/engine (draft) or the demo (final). "If a supplier state stops, here is the downstream output at risk. This is a supply-side model with no substitution: an upper bound, not a forecast."

**2:25–3:00 — Honesty and next steps.** "Today the engine and tests work. Next: the Atlas loader, the map, path explanations and an automatic risk brief. Thank you."

Tips: sentence-level honesty beats hype; state the 2018 base year out loud; keep under 3:00.
