# MALHA

**Brazilian supply-chain dependency intelligence.**
MALHA shows which Brazilian states and sectors a supply chain really depends on (including suppliers of suppliers) and estimates what is lost downstream if one of them stops.

> Hack Brasil 2026 · Track: **Logística & Automação** · Status: **MVP in development**

- Project page: _coming soon (GitHub Pages)_
- Live demo: _coming soon_
- Demo video: _coming soon_

## The problem

A buyer or supply planner usually sees only direct suppliers. The real exposure sits further upstream: a sector in one state may feed the sectors that feed yours. Public input-output tables describe these flows, but they are large matrices that are hard to read and are mostly used for macroeconomic studies, not for sourcing-risk questions.

## The solution

For a chosen state × sector, MALHA answers three questions:

1. **Who do I depend on?** Direct and indirect suppliers, ranked, with an input-concentration index.
2. **Why?** The paths that explain each dependency (planned).
3. **What if a supplier region stops?** A supply-side scenario showing the downstream output at risk, always labelled with the model and its limits.

## Status

| Capability | State |
|---|---|
| Input-output engine: technical coefficients, Leontief inverse, demand shocks | Implemented, tested |
| Supply-side model (Ghosh) and hypothetical extraction of states/sectors | Implemented, tested |
| Input-concentration index (HHI) | Implemented, tested |
| Atlas Econômico data loader and validation | In progress |
| Interactive map and dependency network | Planned |
| Dependency path explanation | Planned |
| Automatic risk brief | Planned |
| Public online demo | Planned |

This table is updated with every milestone. Nothing marked "Planned" is claimed to work.

## Data

Interregional input-output matrix from the Atlas Econômico (IPEA / Receita Federal): 27 states, 68 activities, base year 2018. See [`data/README.md`](data/README.md). Raw files are not stored in this repository.

## Method

- **Demand-driven (Leontief):** `A = Z·diag(x)⁻¹`, `L = (I − A)⁻¹`, `Δx = L·Δf`. Shows how a change in demand propagates to suppliers.
- **Supply-driven (Ghosh):** `B = diag(x)⁻¹·Z`, `G = (I − B)⁻¹`, `x = v·G`. Shows how a supply disruption propagates to buyers.
- **Hypothetical extraction:** zero the trade of selected nodes in the supply-driven model and measure the output lost by the rest of the economy.
- **Concentration:** Herfindahl index of the inputs a node buys.

### Limitations

- Base year is 2018; structure may have changed.
- Fixed coefficients and **no substitution**: results are an upper bound on short-run exposure, not a forecast.
- No inventories, individual companies, transport capacity or physical infrastructure.
- Scenarios are hypothetical and illustrate structure only.

## Run it

Requires Python 3.11+.

```bash
git clone https://github.com/<your-username>/malha.git
cd malha
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
PYTHONPATH=src python -m pytest -q
```

Example (toy 3-node economy):

```python
import numpy as np
from malha import supply_extraction

Z = np.array([[10, 30, 0], [0, 10, 40], [0, 0, 5]], dtype=float)  # intermediate flows
x = np.array([100, 100, 100], dtype=float)                          # total output
print(supply_extraction(Z, x, [0])["loss_by_node"])                 # downstream loss if node 0 stops
```

## Repository layout

```
src/malha/      calculation engine (input-output models, concentration)
tests/          unit tests for every calculation
data/           data notes (raw files are git-ignored)
docs/           project page (GitHub Pages) and video script
```

## License

MIT. See [LICENSE](LICENSE).

## Acknowledgments

Built on public data and research from IPEA and the Receita Federal do Brasil.
